{{- define "kinetica-operators.all-wboperator-operator" }}

---
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app.kubernetes.io/name: wboperator
    app.kubernetes.io/managed-by: Helm
    app.kubernetes.io/instance: '{{ .Release.Name }}'
    helm.sh/chart: '{{ include "kinetica-operators.chart" . }}'
    control-plane: controller-manager
  name: workbench-operator-controller-manager
  namespace: '{{ .Release.Namespace }}'
spec:
  replicas: 1
  selector:
    matchLabels:
      control-plane: controller-manager
  template:
    metadata:
      labels:
        app.kubernetes.io/name: wboperator
        control-plane: controller-manager
    spec:
      containers:
      - args:
        - --metrics-bind-address=:8443
        - --enable-leader-election
        command:
        - /manager
        env:
        - name: WATCH_NAMESPACE
          value: '{{ .Values.kineticacluster.namespace }}'
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
        image: '{{ include "kinetica-operators.image" (dict "registry" (.Values.wbOperator.image.registry
          | default .Values.global.image.registry) "repository" .Values.wbOperator.image.repository
          "tag" .Values.wbOperator.image.tag "digest" .Values.wbOperator.image.digest)
          }}'
        name: manager
        resources:
          limits:
            cpu: 100m
            memory: 256Mi
          requests:
            cpu: 100m
            memory: 256Mi
        securityContext:
          allowPrivilegeEscalation: false
          capabilities:
            drop:
            - ALL
          runAsNonRoot: true
          seccompProfile:
            type: RuntimeDefault
        volumeMounts:
        - mountPath: /etc/config/
          name: workbench-tmpl
      securityContext:
        fsGroup: 2000
        runAsGroup: 3000
        runAsNonRoot: true
        runAsUser: 65432
      serviceAccountName: workbench-operator-service-account
      terminationGracePeriodSeconds: 10
      volumes:
      - configMap:
          name: workbench-tmpl
        name: workbench-tmpl
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}

{{- end }}